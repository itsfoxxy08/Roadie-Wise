#Note:Make sure that all the files,images,audio files are placed in the same file directory as the program location.
#All modules and packages must be installed , including mysql connector, seaborn, matplotlib, pandas for the working.
import tkinter as tk
from tkinter import messagebox, scrolledtext
import mysql.connector as con
import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns
from PIL import Image, ImageTk
import pygame
import random #type:ignore

h = "" # host
u = "" #user
p= ""  # password
d= "" # database

def connect_to_sql():
    try:
        c1 = con.connect(
            host=h,
            user=u,
            password=p
        )
        return c1
    except con.Error as err:
        print(f"Connection Error: {err}")
        return None

def create_database(cur):
    try:
        cur.execute(f"CREATE DATABASE IF NOT EXISTS {d}")
        print(f"Database '{d}'created.")
    except con.Error as err:
        print(f"Database creation error: {err}")

def use_database(cur):
    try:
        cur.execute(f'use {d}')
    except con.Error as err:
        print(f"Database connection error: {err}")
        return None

def fetchdata(c1):
    q=('select * from accidents') # query
    df = pd.read_sql(q,c1)
    return df


def analyze_and_visualize(c1):
    df = fetchdata(c1) 
    sns.set_style('whitegrid')

    # graph 1 (Number of accidents by vehicle type)
    plt.figure(figsize=(10, 6))
    sns.countplot(data=df, x='Vehicle_Type', palette='viridis')
    plt.title('Number of Accidents by Vehicle Type')
    plt.xlabel('Vehicle Type')
    plt.ylabel('Number of Accidents')
    plt.xticks(rotation=45)
    plt.tight_layout()
    plt.show()

    # graph2(Total injuries and fatalities by cause of accident)
    plt.figure(figsize=(12, 6))
    cause = df.groupby('Cause_of_Accident')[['Number_of_Injuries', 'Number_of_Fatalities']].sum().reset_index()
    cause = pd.melt(cause, id_vars='Cause_of_Accident', value_vars=['Number_of_Injuries', 'Number_of_Fatalities'])
    sns.barplot(data=cause, x='Cause_of_Accident', y='value', hue='variable', palette='pastel')
    plt.title('Injuries and Fatalities by Cause of Accident')
    plt.xlabel('Cause of Accident')
    plt.ylabel('Count')
    plt.xticks(rotation=45)
    plt.tight_layout()
    plt.show()

    #graph3(How accidents could be avoided)
    a= df['How_Accident_Could_Be_Avoided'].value_counts() 
    plt.figure(figsize=(10, 6))
    sns.barplot(x=a.index, y=a.values, palette='magma')
    plt.title('How Accidents Could Be Avoided')
    plt.xlabel('Preventive Measures')
    plt.ylabel('Frequency')
    plt.xticks(rotation=45)
    plt.tight_layout()
    plt.show()


def create_table(cur):  
    cur.execute("""CREATE TABLE IF NOT EXISTS Accidents (
                        ID INT AUTO_INCREMENT PRIMARY KEY,
                        Location VARCHAR(100),
                        Vehicle_Type VARCHAR(50),
                        Cause_of_Accident VARCHAR(100),
                        Number_of_Injuries INT,
                        Number_of_Fatalities INT,
                        How_Accident_Could_Be_Avoided VARCHAR(200)
                      )""")

def insert_sample_data(cur, c1):
    cur.execute("SELECT COUNT(*) FROM Accidents")
    rc = cur.fetchone()[0]  # rc = row count
    if rc == 0:
        cur.execute("INSERT INTO Accidents (Location, Vehicle_Type, Cause_of_Accident, Number_of_Injuries, Number_of_Fatalities, How_Accident_Could_Be_Avoided) VALUES ('Delhi', 'Car', 'Over-speeding', 2, 0, 'Adhere to speed limits')")
        cur.execute("INSERT INTO Accidents (Location, Vehicle_Type, Cause_of_Accident, Number_of_Injuries, Number_of_Fatalities, How_Accident_Could_Be_Avoided) VALUES ('Delhi', 'Motorcycle', 'Drunk driving', 1, 1, 'Avoid alcohol before driving')")
        cur.execute("INSERT INTO Accidents (Location, Vehicle_Type, Cause_of_Accident, Number_of_Injuries, Number_of_Fatalities, How_Accident_Could_Be_Avoided) VALUES ('Mumbai', 'Truck', 'Negligent driving', 3, 0, 'Regular driver training')")
        cur.execute("INSERT INTO Accidents (Location, Vehicle_Type, Cause_of_Accident, Number_of_Injuries, Number_of_Fatalities, How_Accident_Could_Be_Avoided) VALUES ('Bengaluru', 'Car', 'Traffic signal violation', 1, 0, 'Obey traffic signals')")
        cur.execute("INSERT INTO Accidents (Location, Vehicle_Type, Cause_of_Accident, Number_of_Injuries, Number_of_Fatalities, How_Accident_Could_Be_Avoided) VALUES ('Chennai', 'Bus', 'Poor weather conditions', 0, 1, 'Drive carefully in adverse weather')")
        cur.execute("INSERT INTO Accidents (Location, Vehicle_Type, Cause_of_Accident, Number_of_Injuries, Number_of_Fatalities, How_Accident_Could_Be_Avoided) VALUES ('Delhi', 'Auto', 'Mechanical failure', 0, 0, 'Regular vehicle maintenance')")
        cur.execute("INSERT INTO Accidents (Location, Vehicle_Type, Cause_of_Accident, Number_of_Injuries, Number_of_Fatalities, How_Accident_Could_Be_Avoided) VALUES ('Delhi', 'Car', 'Driving under the influence', 4, 2, 'Do not drink and drive')")
        cur.execute("INSERT INTO Accidents (Location, Vehicle_Type, Cause_of_Accident, Number_of_Injuries, Number_of_Fatalities, How_Accident_Could_Be_Avoided) VALUES ('Mumbai', 'Motorcycle', 'Over-speeding', 1, 0, 'Adhere to speed limits')")
        cur.execute("INSERT INTO Accidents (Location, Vehicle_Type, Cause_of_Accident, Number_of_Injuries, Number_of_Fatalities, How_Accident_Could_Be_Avoided) VALUES ('Bengaluru', 'Bus', 'Negligent driving', 2, 1, 'Regular driver training')")
        cur.execute("INSERT INTO Accidents (Location, Vehicle_Type, Cause_of_Accident, Number_of_Injuries, Number_of_Fatalities, How_Accident_Could_Be_Avoided) VALUES ('Chennai', 'Truck', 'Traffic signal violation', 0, 0, 'Obey traffic signals')")
        cur.execute("INSERT INTO Accidents (Location, Vehicle_Type, Cause_of_Accident, Number_of_Injuries, Number_of_Fatalities, How_Accident_Could_Be_Avoided) VALUES ('Delhi', 'Car', 'Poor road conditions', 1, 0, 'Report potholes and road hazards')")
        cur.execute("INSERT INTO Accidents (Location, Vehicle_Type, Cause_of_Accident, Number_of_Injuries, Number_of_Fatalities, How_Accident_Could_Be_Avoided) VALUES ('Delhi', 'Auto', 'Driver fatigue', 1, 0, 'Take breaks during long drives')")
        cur.execute("INSERT INTO Accidents (Location, Vehicle_Type, Cause_of_Accident, Number_of_Injuries, Number_of_Fatalities, How_Accident_Could_Be_Avoided) VALUES ('Mumbai', 'Motorcycle', 'Vehicle malfunction', 0, 0, 'Regular vehicle maintenance')")
        cur.execute("INSERT INTO Accidents (Location, Vehicle_Type, Cause_of_Accident, Number_of_Injuries, Number_of_Fatalities, How_Accident_Could_Be_Avoided) VALUES ('Bengaluru', 'Car', 'Distracted driving', 2, 0, 'Stay focused while driving')")
        cur.execute("INSERT INTO Accidents (Location, Vehicle_Type, Cause_of_Accident, Number_of_Injuries, Number_of_Fatalities, How_Accident_Could_Be_Avoided) VALUES ('Chennai', 'Bus', 'Reckless driving', 2, 1, 'Regular driver training')")
        cur.execute("INSERT INTO Accidents (Location, Vehicle_Type, Cause_of_Accident, Number_of_Injuries, Number_of_Fatalities, How_Accident_Could_Be_Avoided) VALUES ('Delhi', 'Truck', 'Poor weather conditions', 1, 0, 'Drive carefully in adverse weather')")
        c1.commit()
    else:
        print("Accidents table already contains data; skipping sample data insertion.")



def recent_accidents_analysis():
    c1 = connect_to_sql()
    if c1:
        cur = c1.cursor()
        create_database(cur)
        use_database(cur)  
        create_table(cur)  
        insert_sample_data(cur,c1)  
        analyze_and_visualize(c1)  
        cur.close()
        c1.close()
    else:
        messagebox.showerror("Connection Error", "Could not connect to the MySQL server.")

def show_traffic_rules():
    # r=rules
    r = """\
    1. Always wear your seatbelt.
    2. Obey speed limits.
    3. Stop for school buses when their lights are flashing.
    4. Never drive under the influence of alcohol or drugs.
    5. Use turn signals when changing lanes or turning.
    6. Yield to pedestrians at crosswalks.
    7. Don’t use your phone while driving.
    8. Always come to a complete stop at stop signs.
    9. Keep a safe distance from the vehicle in front of you.
    10. Adhere to traffic signals and signs.
    11. Check your blind spots before changing lanes.
    12. Do not run red lights.
    13. Use headlights in low visibility conditions (e.g., rain, fog).
    14. Keep your vehicle in good working condition (brakes, tires, lights).
    15. Be cautious of cyclists and give them space.

    For more info: https://docs.google.com/document/d/16PXvJkqeZi8KRJ1zKCMB4v59GIF47KfhDy3Cmtkqbss/edit?usp=sharing 
    Brought into public interest by Govt of India
    """
    rwin = tk.Toplevel(root) # rules window
    rwin.title("Traffic Rules")
    rwin.geometry("800x600")
    rwin.config(bg="#1c1c1c")
    rwin.resizable(False, False) 
    f = tk.Frame(rwin, bg="#2c2c2c", bd=5, relief=tk.GROOVE) # f = frame
    f.pack(expand=True, fill='both', padx=10, pady=10)
    t = tk.Label(f, text="Traffic Rules", font=("Courier", 48, "bold"), fg="#00ffcc", bg="#2c2c2c") # t=title
    t.pack(pady=10)
    ta= scrolledtext.ScrolledText(f, wrap=tk.WORD, font=("Courier", 26), fg="#ffffff", bg="#2c2c2c") # ta=text area
    ta.insert(tk.INSERT, r)
    ta.configure(state='disabled')
    ta.pack(expand=True, fill='both', padx=10, pady=10)

def show_traffic_symbols():
    swin = tk.Toplevel(root) #sw = window for symbols
    swin.title("Traffic Symbols")
    swin.geometry("600x800") 
    swin.config(bg="#1c1c1c")
    swin.resizable(False, False) 
    f = tk.Frame(swin, bg="#1c1c1c") # f=frame
    f.pack(expand=True, fill='both', padx=10, pady=10)
    t = tk.Label(f, text="Traffic Signs", font=("Courier", 36, "bold"), fg="cyan", bg="#1c1c1c") # t = title
    t.pack(pady=30)
    imgs = ["ts1.jpg", "ts2.jpg"]
    i = 0 # i = indx of img
    def update_image():
        try:
            img = Image.open(imgs[i])
            img.thumbnail((600, 500), Image.LANCZOS)
            pic = ImageTk.PhotoImage(img)
            imgl.config(image=pic)
            imgl.img = pic 
        except Exception as e:
            messagebox.showerror("Error", f"Could not load image: {str(e)}")
    imgl = tk.Label(f, bg="#1c1c1c") # imgl = image lable
    imgl.pack(pady=20)
    update_image()
    def next_img():
        nonlocal i
        i = (i + 1) % len(imgs)
        update_image()
    def previous_img():
        nonlocal i
        i = (i - 1) % len(imgs)  
        update_image()
    # pb = previous button
    pb = tk.Button(f, text="Previous", font=("Courier", 16), fg="black", bg="cyan", command=previous_img)
    pb.pack(side=tk.LEFT, padx=10)
    # nb = next button
    nb = tk.Button(f, text="Next", font=("Courier", 16), fg="black", bg="cyan", command=next_img)
    nb.pack(side=tk.RIGHT, padx=10)


def show_input_screen():
    lable.pack_forget()
    nl.pack(pady=5)
    ne.pack(pady=5)
    al.pack(pady=5)
    ae.pack(pady=5)
    cont1.pack(pady=20)

def show_options_screen():
    nl.pack_forget()
    ne.pack_forget()
    al.pack_forget()
    ae.pack_forget()
    cont1.pack_forget()
    center_buttons()

def center_buttons():
    for button in [ab, gb, tr, ts]:
        button.pack(pady=20, padx=20, fill=tk.X)

def game():
    pygame.init()

    # Screen dimensions
    ws = 900
    hs = 600

    #tips for playing
    driving_tips = [
        "Always wear your seatbelt.",
        "Follow speed limits strictly.",
        "Keep a safe following distance.",
        "Avoid distractions while driving.",
        "Use turn signals for lane changes.",
        "Stop for pedestrians at crossings.",
        "Don't drink and drive.",
        "Check mirrors before changing lanes.",
        "Stay calm in heavy traffic.",
        "Maintain your vehicle regularly."
    ]

    #variables set for colours 
    WHITE = (255, 255, 255)
    BLACK = (0, 0, 0)
    GRAY = (169, 169, 169)
    RED = (255, 0, 0)
    GREEN = (0, 255, 0)

    # Load images
    player_car = pygame.image.load("p1s.png")  
    road = pygame.image.load("road.png")
    grass = pygame.image.load("grass.jpg")
    alert = pygame.mixer.Sound('alert.mp3')
    go = pygame.mixer.Sound('go.mp3')
    bgm = pygame.mixer.Sound('night_shade.mp3')
    background_image = pygame.image.load('background_image.png')  
    start_button_image =pygame.image.load('start_button.png')    
    quit_button_image =pygame.image.load('quit_button.png')      

    start_button_image = pygame.transform.scale(start_button_image, (200, 100))
    quit_button_image = pygame.transform.scale(quit_button_image, (200, 100))



    #obstacle images are loaded here, it is in list format
    obstacle_images = [
        pygame.image.load("obstacle1.png"),
        pygame.image.load("obstacle2.png"),
        pygame.image.load("obstacle3.png"),
        pygame.image.load("obstacle4.png")
    ]
    # Load traffic light images
    red_light = pygame.image.load("red_light.png")
    yellow_light = pygame.image.load("yellow_light.png")
    green_light = pygame.image.load("green_light.png")
    speed_sign = pygame.image.load("speed20.png")
    stop_sign = pygame.image.load("stop.png")
    red_light = pygame.transform.scale(red_light, (100, 200))
    yellow_light = pygame.transform.scale(yellow_light, (100, 200))
    green_light = pygame.transform.scale(green_light, (100, 200))
    speed_sign = pygame.transform.scale(speed_sign,(100,100))
    stop_sign = pygame.transform.scale(stop_sign, (100, 100))
    background_image = pygame.transform.scale(background_image,(900,600))



    # Traffic light system variables
    traffic_light_timer = 0
    score=0
    light_cycle_duration = 90* 60  #this is because 60fps
    alert_displayed = False
    message_displayed = False


    #loading the explosion sound
    explosion_sound = pygame.mixer.Sound("explosion.mp3")

    #loading explosion frames (note: pygame does not support gifs, that is why i chose to add multiple frames)
    explosion_frames = [
        pygame.image.load(f"explosion{i}.png") for i in range(11)
    ]


    #scaling images:
    player_car = pygame.transform.scale(player_car, (50, 100))
    road = pygame.transform.scale(road, (400, 600))  
    grass = pygame.transform.scale(grass, (300, 600))  
    obstacle_images = [pygame.transform.scale(img, (50,100)) for img in obstacle_images]

    explosion_frames = [pygame.transform.scale(img, (100, 100)) for img in explosion_frames]


    #display setup
    screen = pygame.display.set_mode((ws, hs))
    pygame.display.set_caption("Roadie Wise")

    #setup font (this is for speedometer)
    font = pygame.font.Font("minecraft.ttf", 26)
    data = pygame.font.Font("minecraft.ttf",18)
    game_over_font = pygame.font.Font("minecraft.ttf", 64)


    #moving road
    def movingroad(offset):
        screen.blit(road, (250, offset))          
        screen.blit(road, (250, offset - 600))    

    #moving grass
    def moving_grass(offset):
        screen.blit(grass, (0, offset))           #left grass segment
        screen.blit(grass, (0, offset - 600))     #left grass reset
        screen.blit(grass, (600, offset))         #right grass segment
        screen.blit(grass, (600, offset - 600))   #right grass reset

    #display of speedometer
    def display_speed(speed):
        speed_text = font.render(f"SPEED: {speed:.0f}", True, BLACK)  #renders the speed text through render function
        pygame.draw.rect(screen, WHITE, [ws - 200, 10, 190, 50])#draws a rectangle using rect draw function
        pygame.draw.rect(screen, BLACK, [ws - 200, 10, 190, 50], 2)#border
        screen.blit(speed_text, (ws - 190, 20))#the speed text

    #score board display
    def display_score(score):
    # Change the position if 
        score_text = font.render(f"SCORE: {score}", True, BLACK)#black colour chosen for rendeering score text
        pygame.draw.rect(screen, WHITE, [10, 10, 190, 50])  #box
        pygame.draw.rect(screen, BLACK, [10, 10, 190, 50], 2)  #border
        screen.blit(score_text, (20, 20)) #display it

    def main_menu():
        while True:
            screen.blit(background_image, (0, 0))  # draw the background
            pygame.mixer.Sound.play(bgm)

            #draw buttons
            screen.blit(start_button_image, (ws // 2 - 100, hs // 2 - 70))  # start button
            screen.blit(quit_button_image, (ws // 2 - 100, hs // 2 + 30))   # quit button

            pygame.display.flip()

            for event in pygame.event.get():
                if event.type == pygame.QUIT:
                    pygame.quit()
                    quit()
                if event.type == pygame.MOUSEBUTTONDOWN:
                    mouse_pos = event.pos
                    # Check for button clicks
                    if (ws // 2 - 100 <= mouse_pos[0] <= ws // 2 + 100 and 
                        hs // 2 - 70 <= mouse_pos[1] <= hs // 2 + 30):
                        bgm.stop()
                        # Start game
                        game_loop()  # Call your game loop here
                    elif (ws // 2 - 100 <= mouse_pos[0] <= ws // 2 + 100 and 
                        hs // 2 + 30 <= mouse_pos[1] <= hs // 2 + 130):
                        # Quit game
                        pygame.quit()
                        quit()


    #function to display the game over message
    def display_game_over_message(x,y,z,n):
        game_over_text = game_over_font.render("GAME OVER!", True, RED)
        drive_safely_text = font.render("YOU HIT A CAR! DRIVE SAFELY!", True, BLACK)
        option_menu_text = font.render("Press Enter to play again, Esc to quit.",True,BLACK)
        obstacle_crossed = data.render(f"No. Of obstacles crossed: {x}",True,BLACK)
        lights_broken = data.render(f"No. of lights broken: {y}",True,BLACK)
        speed_broken = data.render(f"Times speed limit was exceeded: {z}",True, BLACK)
        sign_broken = data.render(f"Times stop sign wasn't followed: {n}",True,BLACK)
        screen.blit(sign_broken,(0,110))
        screen.blit(obstacle_crossed,(0,80))
        screen.blit(lights_broken,(0,20))
        screen.blit(speed_broken,(0,50))
        screen.blit(game_over_text, (ws // 2 - 150, hs // 2 - 50))
        screen.blit(drive_safely_text, (ws // 2 - 200, hs // 2 +20))
        screen.blit(option_menu_text, (ws//2 -250, hs//2+80))
    #main game loop
    def game_loop():
        global traffic_light_timer, alert_displayed, message_displayed,score 
        traffic_light_timer = 0  #Initialize the timer
        alert_displayed = False  #Initialize alert display flag
        message_displayed = False  #Initialize message display flag
        x=0
        y=0
        z=0
        n=0
        p1_X = 450  #this is car's x-axis position
        p1_y = hs * 0.8 #car's y-axis position, here we have fixed it, it remains constant no matter what
        p1_x2 = 0
        road_offset = 0  #offset means the degree of deviation of this path from original in y axis (road is moving downward)
        road_speed = 0   #the pixels at which road moves down PER FRAME
        max_speed = 100  #the max speed 
        min_speed = 0    #the minimum speed
        acceleration_rate = 2  #speed increases at rate (Acceleration)
        deceleration_rate = 4  #speed decrease rate(retardation)

        obstacles = []  #an empty list, this is list for Possible obstacle poistions
        obstacle_spawn_timer = 0  #timer for its spawn
        obstacle_spawn_interval = 60  #interval between spawning (this is in FRAMES)
        

        score = 0  #inital score set to 0
        k=None
        alert_played = False
        tip_displayed = False
        tip2_displayed = False
        go_played = False
        explosion_playing = False  # Track if explosion is playing
        explosion_frame_index = 0  # Index for explosion frames
        game_over = False
        clock = pygame.time.Clock()

        speed_up_pressed = False  #this checks if up arrow is pressed or not

        

        while not game_over:
            for event in pygame.event.get():
                if event.type == pygame.KEYDOWN:
                    if event.key == pygame.K_LEFT:
                        p1_x2 = -5
                    elif event.key == pygame.K_RIGHT:
                        p1_x2 = 5
                    elif event.key == pygame.K_UP:
                        speed_up_pressed = True  # Start acceleratin
                    elif event.key == pygame.K_DOWN:
                        road_speed -= deceleration_rate  # Instant stop when down arrow is pressed

                if event.type == pygame.KEYUP:
                    if event.key == pygame.K_LEFT or event.key == pygame.K_RIGHT:
                        p1_x2 = 0
                    if event.key == pygame.K_UP:
                        
                        # Update the flag
                        speed_up_pressed = False  # Stop accelerating


            #this is continuously checking for arrow key pressed or not
            if speed_up_pressed == True:
                road_speed += acceleration_rate / 60  
            else:
                road_speed -= deceleration_rate / 60  
                


                
            #limiting the maximum speed and MINIMUM speed aswell.
            if road_speed > max_speed:
                road_speed = max_speed
            elif road_speed < min_speed:
                road_speed = min_speed

            #player position change (on x- axis)
            p1_X += p1_x2

            #restrict player motion between x = 250 and x = 650
            if p1_X < 250:
                p1_X = 250
            elif p1_X > 650 - 50:  
                p1_X = 650 - 50

            traffic_light_timer+=1

            if traffic_light_timer >= light_cycle_duration:
                # Reset timer
                traffic_light_timer = 0
                alert_displayed = False
                message_displayed = False

            #update the vertical offset for the road and grass
            road_offset += road_speed
            if road_offset >= 600:  #reset the postion of road so it is in loop
                road_offset = 0

            # Random obstacles
            obstacle_spawn_timer += 1
            if obstacle_spawn_timer >= obstacle_spawn_interval:
                if road_speed > 0:  # Only spawn obstacles if the road speed is greater than 0
                    obstacle_x = random.randint(250, 650 - 50)  # Choose a random x-position
                    obstacle_image = random.choice(obstacle_images)
                    obstacles.append((obstacle_x, -100, obstacle_image))  #append the new obstacle
                obstacle_spawn_timer = 0  # Reset the timer


            #obstacles will move down (SAME SPEED AS THAT OF ROAD, SO ACCCELERATION ALSO APPLIES HERE)
            for i in range(len(obstacles)):
                obstacles[i] = (obstacles[i][0], obstacles[i][1] + road_speed, obstacles[i][2])  #move down

            #collision chcker
            for obs in obstacles:
                obs_rect = pygame.Rect(obs[0], obs[1], 50, 50)  #this is like a hitbox area for obstacle
                player_rect = pygame.Rect(p1_X, p1_y, 50, 100)  #hitbox for player
                if player_rect.colliderect(obs_rect)and explosion_playing == False:
                    explosion_sound.play()  #sound will be played
                    explosion_playing = True  #explosion will start
                    game_over = True  #or bumped= true

            #scoring mechanism (this is based on no. of obstacles you will pass through)
            obstacles_to_remove = []
            for obs in obstacles:
                if obs[1] > hs:  #this will check if the obstacles is off the screen or not, because if it is , then it is of no use and we remove it.
                    obstacles_to_remove.append(obs)  #this obs will be marked for removal
                    x+=1
                    score += 10  #since you passed the obstacle, score increases by 1
        
            #these obstacles will go off the screen, so we remove them from original list
            obstacles = [obs for obs in obstacles if obs not in obstacles_to_remove]

            #calling function of moving grass and moving road
            moving_grass(road_offset)  #moving grass on both sides ( i chose road_offset here because i want the grass and road to move at same SPEED)
            movingroad(road_offset)   #moving road

            #draw player car 
            screen.blit(player_car, (p1_X, p1_y))

            #obstacles
            for obs in obstacles:
                screen.blit(obs[2], (obs[0], obs[1]))
                
            if 0<traffic_light_timer<240 and not tip_displayed:
                control_text = font.render("Use arrow keys to control the game!",True,BLACK)
                text_rect = control_text.get_rect(center= (ws//2,hs//2))
                pygame.draw.rect(screen,(255,255,255),text_rect.inflate(40,40))
                pygame.draw.rect(screen,(0,0,0),text_rect.inflate(40,40),5)
                screen.blit(control_text,text_rect)
            
            if 240<traffic_light_timer<380 and not tip2_displayed:
                control_text = font.render("Watch cars on the road, do not collide!",True,BLACK)
                text_rect = control_text.get_rect(center= (ws//2,hs//2))
                pygame.draw.rect(screen,(255,255,255),text_rect.inflate(40,40))
                pygame.draw.rect(screen,(0,0,0),text_rect.inflate(40,40),5)
                screen.blit(control_text,text_rect)
            

            if 600<traffic_light_timer <720 and not alert_displayed:
                pygame.mixer.Sound.play(alert)
                alert_text = font.render("ALERT! RED LIGHT AHEAD", True, RED)
                text_rect = alert_text.get_rect(center=(ws // 2, hs // 2))
                pygame.draw.rect(screen, (255, 255, 255), text_rect.inflate(40, 40))
                pygame.draw.rect(screen, (0, 0, 0), text_rect.inflate(40, 40), 5) 
                screen.blit(alert_text,text_rect)
            elif 720<= traffic_light_timer < 870:
                pygame.mixer.Sound.play(alert)
                screen.blit(red_light, (ws - 150, 100))
                if traffic_light_timer==720:  # Only check once when the red light shows
                    if road_speed > 0:
                        score -= 30
                        y+=1
                        k=True  # Deduct points for running red light
                    else:
                        score += 50
                        k= False  # Gain points for stopping
                if 760<traffic_light_timer<820:
                    if k==True:
                        deduction = data.render("-30 POINTS FOR BREAKING LIGHT!",True,BLACK)
                        ded_rect = deduction.get_rect(center= (ws//2,40))
                        pygame.draw.rect(screen,(255,255,255),ded_rect.inflate(40,40))
                        pygame.draw.rect(screen,(0,0,0),ded_rect.inflate(40,40),5)
                        screen.blit(deduction,ded_rect)
                    elif k==False:
                        increment = data.render("+50 POINTS FOR FOLLOWING LIGHT!",True,BLACK)
                        inc_rect = increment.get_rect(center= (ws//2,40))
                        pygame.draw.rect(screen,(255,255,255),inc_rect.inflate(40,40))
                        pygame.draw.rect(screen,(0,0,0),inc_rect.inflate(40,40),5)
                        screen.blit(increment,inc_rect)
        
            elif 870 <= traffic_light_timer < 990:
                pygame.mixer.Sound.play(alert)
                screen.blit(yellow_light, (ws - 150, 100))
                if traffic_light_timer ==870:  #Only check once when yellow light shows
                    if road_speed > 0:
                        score -= 20
                        k=True
                        y+=1   #Deduct points for running yellow light
                    else:
                        score += 30
                        k=False  #Gain points for stopping, similar logic is used below...
                if 930<traffic_light_timer<990 and k==True:
                    deduction = data.render("-20 POINTS FOR BREAKING LIGHT!",True,BLACK)
                    ded_rect = deduction.get_rect(center= (ws//2,40))
                    pygame.draw.rect(screen,(255,255,255),ded_rect.inflate(40,40))
                    pygame.draw.rect(screen,(0,0,0),ded_rect.inflate(40,40),5)
                    screen.blit(deduction,ded_rect)
                elif 930<traffic_light_timer<990 and k==False :
                    increment = data.render("+30 POINTS FOR FOLLOWING LIGHT!",True,BLACK)
                    inc_rect = increment.get_rect(center= (ws//2,40))
                    pygame.draw.rect(screen,(255,255,255),inc_rect.inflate(40,40))
                    pygame.draw.rect(screen,(0,0,0),inc_rect.inflate(40,40),5)
                    screen.blit(increment,inc_rect)            
            elif 990 <= traffic_light_timer < 1060:
                pygame.mixer.Sound.play(go)
                screen.blit(green_light, (ws - 150, 100))
                go_text = font.render("GO!", True,GREEN)
                go_text_rect = go_text.get_rect(center=(ws // 2, hs // 2))
                pygame.draw.rect(screen, (255, 255, 255), go_text_rect.inflate(40, 40))
                pygame.draw.rect(screen, (0, 0, 0), go_text_rect.inflate(40, 40), 5)
                screen.blit(go_text,go_text_rect)
            elif 1660<= traffic_light_timer <= 2060:
                if not go_played:
                    pygame.mixer.Sound.play(go)
                    go_played=True
                if traffic_light_timer==2060:
                    if road_speed >20:
                        score-=10
                        k=True
                        z+=1
                    else:
                        score+=20
                        k=False
                screen.blit(speed_sign,(10,500))
                speed_warning = font.render("WATCH FOR SPEED!", True, RED)
                text_rect = speed_warning.get_rect(center=(ws // 2, hs // 2))
                pygame.draw.rect(screen, (255, 255, 255), text_rect.inflate(40, 40))
                pygame.draw.rect(screen, (0, 0, 0), text_rect.inflate(40, 40), 5) 
                screen.blit(speed_warning,text_rect)
                if 1800<traffic_light_timer<2060 and k==True:
                    deduction = data.render("-10 POINTS FOR OVERSPEEDING!",True,BLACK)
                    ded_rect = deduction.get_rect(center= (ws//2,40))
                    pygame.draw.rect(screen,(255,255,255),ded_rect.inflate(40,40))
                    pygame.draw.rect(screen,(0,0,0),ded_rect.inflate(40,40),5)
                    screen.blit(deduction,ded_rect)
                elif 1800<traffic_light_timer<2060 and k==False:
                    increment = data.render("+20 POINTS FOR FOLLOWING LIMIT!",True,BLACK)
                    inc_rect = increment.get_rect(center= (ws//2,40))
                    pygame.draw.rect(screen,(255,255,255),inc_rect.inflate(40,40))
                    pygame.draw.rect(screen,(0,0,0),inc_rect.inflate(40,40),5)
                    screen.blit(increment,inc_rect)
            elif 2400<=traffic_light_timer<=2600:
                if traffic_light_timer==2400:
                    tip = random.choice(driving_tips)
                tip_text = data.render(tip,True,GREEN)
                text_rect = tip_text.get_rect(center = (ws//2, 40))
                pygame.draw.rect(screen,(255,255,255),text_rect.inflate(40,40))
                pygame.draw.rect(screen,(0,0,0),text_rect.inflate(40,40),5)
                screen.blit(tip_text,text_rect)
            elif 3000<=traffic_light_timer<=3200:
                if traffic_light_timer==3000:
                    tip = random.choice(driving_tips)
                tip_text = data.render(tip,True,RED)
                text_rect = tip_text.get_rect(center= (ws//2, 40))
                pygame.draw.rect(screen,(255,255,255),text_rect.inflate(40,40))
                pygame.draw.rect(screen,(0,0,0),text_rect.inflate(40,40),5)
                screen.blit(tip_text,text_rect)
            elif 3600<=traffic_light_timer<=3800:
                    warning = font.render("STOP! HEAVY TRAFFIC FURTHER!",True,RED)
                    text_rect = warning.get_rect(center= (ws//2,hs//2))
                    pygame.draw.rect(screen,(255,255,255),text_rect.inflate(40,40))
                    pygame.draw.rect(screen,(0,0,0),text_rect.inflate(40,40),5)
                    screen.blit(warning,text_rect)
            elif 3800<=traffic_light_timer<=4800:
                if not alert_played:
                    pygame.mixer.Sound.play(alert)
                screen.blit(stop_sign,(10,500))
                if traffic_light_timer==4050:
                    if road_speed>0:
                        score-=30 
                        k = True
                        n+= 1
                    else:
                        score+=30
                        k = False
                        
                if 4400<traffic_light_timer<4800 and k==True:
                    deduction = data.render("-20 POINTS FOR BREAKING!",True,BLACK)
                    ded_rect = deduction.get_rect(center= (ws//2,40))
                    pygame.draw.rect(screen,(255,255,255),ded_rect.inflate(40,40))
                    pygame.draw.rect(screen,(0,0,0),ded_rect.inflate(40,40),5)
                    screen.blit(deduction,ded_rect)
                elif 4400<traffic_light_timer<4800 and k==False:
                    increment = data.render("+30 POINTS FOR FOLLOWING SIGN!",True,BLACK)
                    inc_rect = increment.get_rect(center= (ws//2,40))
                    pygame.draw.rect(screen,(255,255,255),inc_rect.inflate(40,40))
                    pygame.draw.rect(screen,(0,0,0),inc_rect.inflate(40,40),5)
                    screen.blit(increment,inc_rect)
            #calling speed function (speedometer)
            display_speed(road_speed)
            
            #callin score function 
            display_score(score)

            #screen update to apply changes
            pygame.display.update()

            #limit fps
            clock.tick(60)
            
        #Explosion handling (basically , we set the timer to 0 here initally)
        explosion_timer = 0  #resetting timer
        while explosion_playing:
            for event in pygame.event.get():
                if event.type == pygame.QUIT:
                    explosion_playing = False  
                    game_over = False  #this will stop the game if window closed

            screen.blit(player_car, (p1_X, p1_y))  #keeping car on screen
            for obs in obstacles:
                screen.blit(obs[2], (obs[0], obs[1]))  #obstacles will be drawn their
            if explosion_frame_index < len(explosion_frames):
                screen.blit(explosion_frames[explosion_frame_index], (p1_X - 25, p1_y - 25))#explosion frames will be displayed but on center of the car, since car dimension is 50,100, this will work

                # Update the frame index based on the timer
                explosion_timer += 1  # Increment timer
                if explosion_timer >= 10:  # Control frame rate of the explosion
                    explosion_frame_index += 1
                    explosion_timer = 0
            else:
                explosion_playing = False  # Stop the explosion after all frames have been displayed

            pygame.display.update()
            clock.tick(60)  
            
        #after game is over, we go here:
        while game_over:
            for event in pygame.event.get():
                if event.type == pygame.QUIT:
                    game_over = False  # To exit the game
                if event.type == pygame.KEYDOWN:
                    if event.key == pygame.K_RETURN:  #this will restart
                        game_loop()  #restart the game
                    if event.key == pygame.K_ESCAPE:  #if u press esc, this will quit the game
                        pygame.quit()
                        quit()

            #fill screen and call the game over function
            screen.fill(WHITE)
            display_game_over_message(x,y,z,n)

            # Display final score
            final_score_text = font.render(f"Final SCORE: {score}", True, BLACK)
            screen.blit(final_score_text, (ws // 2 - 100, hs // 2 + 50))

            #this will stay in loop
            pygame.display.update()

            #fps limit
            clock.tick(60)

    #calling functions
    main_menu()
    game_loop()
    pygame.quit()
    quit()

def mysql_info():
    win = tk.Toplevel(root)
    win.title("MySQL Credentials")
    win.geometry("400x400")
    win.config(bg="black")
    win.resizable(False, False)

    l = tk.Label(win, text="MySQL Host:", font=("Courier", 14), fg="cyan", bg="black")
    # l =lable , e=entry 
    l.pack(pady=5)
    e = tk.Entry(win, font=("Courier", 14), fg="cyan", bg="black", insertbackground="cyan")
    e.pack(pady=5)

    l2 = tk.Label(win, text="MySQL User:", font=("Courier", 14), fg="cyan", bg="black")
    l2.pack(pady=5)
    e2 = tk.Entry(win, font=("Courier", 14), fg="cyan", bg="black", insertbackground="cyan")
    e2.pack(pady=5)

    l3 = tk.Label(win, text="MySQL Password:", font=("Courier", 14), fg="cyan", bg="black")
    l3.pack(pady=5)
    e3 = tk.Entry(win, font=("Courier", 14), fg="cyan", bg="black", show="*", insertbackground="cyan")
    e3.pack(pady=5)

    l4 = tk.Label(win, text="Database Name:", font=("Courier", 14), fg="cyan", bg="black")
    l4.pack(pady=5)
    e4 = tk.Entry(win, font=("Courier", 14), fg="cyan", bg="black", insertbackground="cyan")
    e4.pack(pady=5)  
    def save():
        global h, u, p, d
        h = e.get()
        u = e2.get()
        p = e3.get()
        d = e4.get()
        c1 = connect_to_sql()
        if c1:
            cur = c1. cursor()
            cur.execute(f"CREATE DATABASE IF NOT EXISTS {d}")
            print(f"Database '{d}'created.")
            cur.close()
            c1.close()
            win.destroy()
            show_input_screen() 
        else:
            messagebox.showerror("Connection Error", "Could not connect to the MySQL server. Please check your credentials.")
    cont = tk.Button(win, text="Continue", font=("Courier", 14), fg="black", bg="cyan", command=save) # cont = continue
    cont.pack(pady=20)

# Root window setup
root = tk.Tk()
root.geometry("600x600") 
root.config(bg="black")
root.title("Trafficwise")
lable= tk.Label(root, text="Trafficwise", font=("Courier", 40, "bold"), fg="cyan", bg="black")
lable.pack(pady=20)
root.after(2000,mysql_info)

name = tk.StringVar()
age = tk.StringVar()
#nl = name lable , ne = name entry
nl = tk.Label(root, text="Enter your Name:", font=("Courier", 24, "bold"), fg="cyan", bg="black")
ne = tk.Entry(root, textvariable=name, font=("Courier", 24, "bold"), fg="cyan", bg="black", insertbackground="cyan")
#al = age lable , ae = age entry
al= tk.Label(root, text="Enter your Age:", font=("Courier", 24, "bold"), fg="cyan", bg="black")
ae = tk.Entry(root, textvariable=age, font=("Courier", 24, "bold"), fg="cyan", bg="black", insertbackground="cyan")
#cont1=continue
cont1 = tk.Button(root, text="Continue", font=("Courier", 18, "bold"), fg="black", bg="cyan", activebackground="cyan", activeforeground="black", command=show_options_screen)

# ab = accident analysis button
ab = tk.Button(root, text="Recent Accidents Analysis", font=("Courier", 28, "bold"), fg="cyan", bg="black", activebackground="cyan", activeforeground="black", command=recent_accidents_analysis)

# gb = game button
gb = tk.Button(root, text="Game", font=("Courier", 30, "bold"), fg="cyan", bg="black", activebackground="cyan", activeforeground="black",command=game)

# tr = traffic rules button
tr = tk.Button(root, text="Traffic Rules", font=("Courier", 30, "bold"), fg="cyan", bg="black", activebackground="cyan", activeforeground="black", command=show_traffic_rules)

# ts = traffic sign button
ts = tk.Button(root, text="Traffic Symbols", font=("Courier", 30, "bold"), fg="cyan", bg="black", activebackground="cyan", activeforeground="black", command=show_traffic_symbols)

# e = mouse pointer pointing the button
def on_enter(e):
    e.widget['bg'] = 'cyan'  
    e.widget['fg'] = 'black'  

def on_leave(e):
    e.widget['bg'] = 'black'  
    e.widget['fg'] = 'cyan'

for button in [ab, gb, tr, ts]:
    button.bind("<Enter>", on_enter)
    button.bind("<Leave>", on_leave)

root.mainloop()















